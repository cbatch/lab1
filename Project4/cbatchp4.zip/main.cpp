//
// seriously modified ZJ Wood January 2015 - conversion to glfw
// inclusion of matrix stack Feb. 2015
// original from Shinjiro Sueda
// October, 2014
//

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cassert>
#include <cmath>
#include <stdio.h>
#include "GLSL.h"
#include "tiny_obj_loader.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp" //perspective, trans etc
#include "glm/gtc/type_ptr.hpp" //value_ptr
#include "RenderingHelper.h"
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <time.h>

GLFWwindow* window;
using namespace std;
using namespace glm;

vector<tinyobj::shape_t> bunny_shapes;
vector<tinyobj::shape_t> skateboard_shapes;
vector<tinyobj::shape_t> monster_can_shapes;
vector<tinyobj::shape_t> monster_logo_shapes;
vector<tinyobj::material_t> materials;
GLuint prog;
// Bunny Obj
GLuint posBufObjB = 0;
GLuint norBufObjB = 0;
GLuint indBufObjB = 0;
// Skateboard Obj
GLuint posBufObjS = 0;
GLuint norBufObjS = 0;
GLuint indBufObjS = 0;
// Monster Can Obj
GLuint posBufObjM = 0;
GLuint norBufObjM = 0;
GLuint indBufObjM = 0;
// Monster Can Obj
GLuint posBufObjL = 0;
GLuint norBufObjL = 0;
GLuint indBufObjL = 0;
// Floor Obj
GLuint posFloorBufObj = 0;
GLuint norFloorBufObj = 0;

//Handles to the shader data
GLint h_aPosition;
GLint h_aNormal;
GLint h_uModelMatrix;
GLint h_uViewMatrix;
GLint h_uProjMatrix;
GLint h_uLightPos;
GLint h_uMatAmb, h_uMatDif, h_uMatSpec, h_uMatShine;

static float g_width, g_height;
static float G_edge = 75;
static int play_area = 60;
float theta = 0.0;
float phi = 0.0;

// Mouse position stuff
double mouseX;
double mouseY;

// CAMERA STUFF
mat4 view;

vec3 cameraPos = vec3(0.0f, 0.0f, 3.0f);
vec3 cameraFront = vec3(0.0f, 0.0f, -1.0f);
vec3 cameraUp = vec3(0.0f, 1.0f, 0.0f);

bool keys[1024];
GLfloat lastX, lastY;
bool firstMouse = true;


//floor depth
static const float FLOOR_DEPTH = -5.0f;
static const float BUNNY_ADJUST = 2.5f;
static const float SKATEBOARD_ADJUST = 0.88f;
static const float MONSTER_ADJUST = 4.27f;

//declare a matrix stack
RenderingHelper ModelTrans;

typedef struct randomizedInfo
{
	mat4 modelMat;
	int material;
};

void loadShapes(const string &objFile, int which)
{
	string err;
	if (which == 1)
	{
		err = tinyobj::LoadObj(bunny_shapes, materials, objFile.c_str());
	}
	else if (which == 2)
	{
		err = tinyobj::LoadObj(monster_can_shapes, materials, objFile.c_str());
	}
	else if (which == 3)
	{
		err = tinyobj::LoadObj(monster_logo_shapes, materials, objFile.c_str());
	}
	else
	{
		err = tinyobj::LoadObj(skateboard_shapes, materials, objFile.c_str());
	}
	if (!err.empty())
	{
		cerr << err << endl;
	}
}

void SetMaterial(int i)
{

	glUseProgram(prog);
	switch (i)
	{
	case 0: //shiny blue plastic
		glUniform3f(h_uMatAmb, 0.02, 0.04, 0.2);
		glUniform3f(h_uMatDif, 0.0, 0.16, 0.9);
		glUniform3f(h_uMatSpec, 0.14, 0.2, 0.8);
		glUniform1f(h_uMatShine, 120.0);
		break;
	case 1: // flat grey
		glUniform3f(h_uMatAmb, 0.13, 0.13, 0.14);
		glUniform3f(h_uMatDif, 0.3, 0.3, 0.4);
		glUniform3f(h_uMatSpec, 0.3, 0.3, 0.4);
		glUniform1f(h_uMatShine, 4.0);
		break;
	case 2: //gold
		glUniform3f(h_uMatAmb, 0.09, 0.07, 0.08);
		glUniform3f(h_uMatDif, 0.91, 0.782, 0.82);
		glUniform3f(h_uMatSpec, 1.0, 0.913, 0.8);
		glUniform1f(h_uMatShine, 200.0);
		break;
	case 3: //gold
		glUniform3f(h_uMatAmb, 0.09, 0.07, 0.08);
		glUniform3f(h_uMatDif, 0.91, 0.2, 0.91);
		glUniform3f(h_uMatSpec, 1.0, 0.7, 1.0);
		glUniform1f(h_uMatShine, 100.0);
		break;
	case 4: // black
		glUniform3f(h_uMatAmb, 0.08, 0.08, 0.08);
		glUniform3f(h_uMatDif, 0.08, 0.08, 0.08);
		glUniform3f(h_uMatSpec, 0.08, 0.08, 0.08);
		glUniform1f(h_uMatShine, 10.0);
		break;
	case 5: // pale
		glUniform3f(h_uMatAmb, 0.23, 0.23, 0.24);
		glUniform3f(h_uMatDif, 0.4, 0.4, 0.5);
		glUniform3f(h_uMatSpec, 0.3, 0.3, 0.4);
		glUniform1f(h_uMatShine, 2.0);
		break;
	case 6: // green
		glUniform3f(h_uMatAmb, 0.2, 0.4, 0.2);
		glUniform3f(h_uMatDif, 0.2, 0.5, 0.3);
		glUniform3f(h_uMatSpec, 0.2, 0.45, 0.2);
		glUniform1f(h_uMatShine, 300.0);
		break;
	case 7: // ground
		glUniform3f(h_uMatAmb, 0.6, 0.6, 0.6);
		glUniform3f(h_uMatDif, 0.1, 0.1, 0.1);
		glUniform3f(h_uMatSpec, 0.1, 0.1, 0.1);
		glUniform1f(h_uMatShine, 2.0);
		break;
	}
}

void initBunny(std::vector<tinyobj::shape_t>& shape)
{
	// Send the position array to the GPU
	const vector<float> &posBufB = bunny_shapes[0].mesh.positions;
	glGenBuffers(1, &posBufObjB);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObjB);
	glBufferData(GL_ARRAY_BUFFER, posBufB.size()*sizeof(float), &posBufB[0], GL_STATIC_DRAW);

	// TODO compute the normals per vertex - you must fill this in 
	vector<float> norBuf;
	int idx1, idx2, idx3;
	vec3 v1, v2, v3;
	//for every vertex initialize a normal to 0
	for (int j = 0; j < bunny_shapes[0].mesh.positions.size() / 3; j++)
	{
		norBuf.push_back(0);
		norBuf.push_back(0);
		norBuf.push_back(0);
	}
	// DO work here to compute the normals for every face
	//then add its normal to its associated vertex
	for (int i = 0; i < bunny_shapes[0].mesh.indices.size() / 3; i++)
	{
		idx1 = bunny_shapes[0].mesh.indices[3 * i + 0];
		idx2 = bunny_shapes[0].mesh.indices[3 * i + 1];
		idx3 = bunny_shapes[0].mesh.indices[3 * i + 2];
		v1 = vec3(bunny_shapes[0].mesh.positions[3 * idx1 + 0], bunny_shapes[0].mesh.positions[3 * idx1 + 1], bunny_shapes[0].mesh.positions[3 * idx1 + 2]);
		v2 = vec3(bunny_shapes[0].mesh.positions[3 * idx2 + 0], bunny_shapes[0].mesh.positions[3 * idx2 + 1], bunny_shapes[0].mesh.positions[3 * idx2 + 2]);
		v3 = vec3(bunny_shapes[0].mesh.positions[3 * idx3 + 0], bunny_shapes[0].mesh.positions[3 * idx3 + 1], bunny_shapes[0].mesh.positions[3 * idx3 + 2]);

		// Normals calculations
		vec3 normal = cross(v2 - v1, v3 - v1);

		norBuf[3 * idx1 + 0] += normal.x;
		norBuf[3 * idx1 + 1] += normal.y;
		norBuf[3 * idx1 + 2] += normal.z;
		norBuf[3 * idx2 + 0] += normal.x;
		norBuf[3 * idx2 + 1] += normal.y;
		norBuf[3 * idx2 + 2] += normal.z;
		norBuf[3 * idx3 + 0] += normal.x;
		norBuf[3 * idx3 + 1] += normal.y;
		norBuf[3 * idx3 + 2] += normal.z;
	}

	glGenBuffers(1, &norBufObjB);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObjB);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);

	// Send the index array to the GPU
	const vector<unsigned int> &indBuf = bunny_shapes[0].mesh.indices;
	glGenBuffers(1, &indBufObjB);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjB);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);

	// Unbind the arrays
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	GLSL::checkVersion();
	//assert(glGetError() == GL_NO_ERROR);
}

void initSkateboard(std::vector<tinyobj::shape_t>& shape)
{
	// Send the position array to the GPU
	const vector<float> &posBufS = skateboard_shapes[0].mesh.positions;
	glGenBuffers(1, &posBufObjS);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObjS);
	glBufferData(GL_ARRAY_BUFFER, posBufS.size()*sizeof(float), &posBufS[0], GL_STATIC_DRAW);

	// TODO compute the normals per vertex - you must fill this in 
	vector<float> norBuf;
	int idx1, idx2, idx3;
	vec3 v1, v2, v3;
	//for every vertex initialize a normal to 0
	for (int j = 0; j < skateboard_shapes[0].mesh.positions.size() / 3; j++)
	{
		norBuf.push_back(0);
		norBuf.push_back(0);
		norBuf.push_back(0);
	}
	// DO work here to compute the normals for every face
	//then add its normal to its associated vertex
	for (int i = 0; i < skateboard_shapes[0].mesh.indices.size() / 3; i++)
	{
		idx1 = skateboard_shapes[0].mesh.indices[3 * i + 0];
		idx2 = skateboard_shapes[0].mesh.indices[3 * i + 1];
		idx3 = skateboard_shapes[0].mesh.indices[3 * i + 2];
		v1 = vec3(skateboard_shapes[0].mesh.positions[3 * idx1 + 0], skateboard_shapes[0].mesh.positions[3 * idx1 + 1], skateboard_shapes[0].mesh.positions[3 * idx1 + 2]);
		v2 = vec3(skateboard_shapes[0].mesh.positions[3 * idx2 + 0], skateboard_shapes[0].mesh.positions[3 * idx2 + 1], skateboard_shapes[0].mesh.positions[3 * idx2 + 2]);
		v3 = vec3(skateboard_shapes[0].mesh.positions[3 * idx3 + 0], skateboard_shapes[0].mesh.positions[3 * idx3 + 1], skateboard_shapes[0].mesh.positions[3 * idx3 + 2]);

		// Normals calculations
		vec3 normal = cross(v2 - v1, v3 - v1);

		norBuf[3 * idx1 + 0] += normal.x;
		norBuf[3 * idx1 + 1] += normal.y;
		norBuf[3 * idx1 + 2] += normal.z;
		norBuf[3 * idx2 + 0] += normal.x;
		norBuf[3 * idx2 + 1] += normal.y;
		norBuf[3 * idx2 + 2] += normal.z;
		norBuf[3 * idx3 + 0] += normal.x;
		norBuf[3 * idx3 + 1] += normal.y;
		norBuf[3 * idx3 + 2] += normal.z;
	}

	glGenBuffers(1, &norBufObjS);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObjS);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);

	// Send the index array to the GPU
	const vector<unsigned int> &indBuf = skateboard_shapes[0].mesh.indices;
	glGenBuffers(1, &indBufObjS);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjS);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);

	// Unbind the arrays
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	GLSL::checkVersion();
	//assert(glGetError() == GL_NO_ERROR);
}

void initMonster(std::vector<tinyobj::shape_t>& shape)
{
	// Send the position array to the GPU
	const vector<float> &posBufM = shape[0].mesh.positions;
	glGenBuffers(1, &posBufObjM);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObjM);
	glBufferData(GL_ARRAY_BUFFER, posBufM.size()*sizeof(float), &posBufM[0], GL_STATIC_DRAW);

	// TODO compute the normals per vertex - you must fill this in 
	vector<float> norBuf;
	int idx1, idx2, idx3;
	vec3 v1, v2, v3;
	//for every vertex initialize a normal to 0
	for (int j = 0; j < monster_can_shapes[0].mesh.positions.size() / 3; j++)
	{
		norBuf.push_back(0);
		norBuf.push_back(0);
		norBuf.push_back(0);
	}
	// DO work here to compute the normals for every face
	//then add its normal to its associated vertex
	for (int i = 0; i < monster_can_shapes[0].mesh.indices.size() / 3; i++)
	{
		idx1 = monster_can_shapes[0].mesh.indices[3 * i + 0];
		idx2 = monster_can_shapes[0].mesh.indices[3 * i + 1];
		idx3 = monster_can_shapes[0].mesh.indices[3 * i + 2];
		v1 = vec3(monster_can_shapes[0].mesh.positions[3 * idx1 + 0], monster_can_shapes[0].mesh.positions[3 * idx1 + 1], monster_can_shapes[0].mesh.positions[3 * idx1 + 2]);
		v2 = vec3(monster_can_shapes[0].mesh.positions[3 * idx2 + 0], monster_can_shapes[0].mesh.positions[3 * idx2 + 1], monster_can_shapes[0].mesh.positions[3 * idx2 + 2]);
		v3 = vec3(monster_can_shapes[0].mesh.positions[3 * idx3 + 0], monster_can_shapes[0].mesh.positions[3 * idx3 + 1], monster_can_shapes[0].mesh.positions[3 * idx3 + 2]);

		// Normals calculations
		vec3 normal = cross(v2 - v1, v3 - v1);

		norBuf[3 * idx1 + 0] += normal.x;
		norBuf[3 * idx1 + 1] += normal.y;
		norBuf[3 * idx1 + 2] += normal.z;
		norBuf[3 * idx2 + 0] += normal.x;
		norBuf[3 * idx2 + 1] += normal.y;
		norBuf[3 * idx2 + 2] += normal.z;
		norBuf[3 * idx3 + 0] += normal.x;
		norBuf[3 * idx3 + 1] += normal.y;
		norBuf[3 * idx3 + 2] += normal.z;
	}

	glGenBuffers(1, &norBufObjM);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObjM);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);

	// Send the index array to the GPU
	const vector<unsigned int> &indBuf = monster_can_shapes[0].mesh.indices;
	glGenBuffers(1, &indBufObjM);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjM);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);

	// Unbind the arrays
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	GLSL::checkVersion();
	//assert(glGetError() == GL_NO_ERROR);
}

void initMonsterLogo(std::vector<tinyobj::shape_t>& shape)
{
	// Send the position array to the GPU
	const vector<float> &posBufL = monster_logo_shapes[1].mesh.positions;
	glGenBuffers(1, &posBufObjL);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObjL);
	glBufferData(GL_ARRAY_BUFFER, posBufL.size()*sizeof(float), &posBufL[0], GL_STATIC_DRAW);

	// TODO compute the normals per vertex - you must fill this in 
	vector<float> norBuf;
	int idx1, idx2, idx3;
	vec3 v1, v2, v3;
	//for every vertex initialize a normal to 0
	for (int j = 0; j < monster_logo_shapes[1].mesh.positions.size() / 3; j++)
	{
		norBuf.push_back(0);
		norBuf.push_back(0);
		norBuf.push_back(0);
	}
	// DO work here to compute the normals for every face
	//then add its normal to its associated vertex
	for (int i = 0; i < monster_logo_shapes[1].mesh.indices.size() / 3; i++)
	{
		idx1 = monster_logo_shapes[1].mesh.indices[3 * i + 0];
		idx2 = monster_logo_shapes[1].mesh.indices[3 * i + 1];
		idx3 = monster_logo_shapes[1].mesh.indices[3 * i + 2];
		v1 = vec3(monster_logo_shapes[1].mesh.positions[3 * idx1 + 0], monster_logo_shapes[1].mesh.positions[3 * idx1 + 1], monster_logo_shapes[1].mesh.positions[3 * idx1 + 2]);
		v2 = vec3(monster_logo_shapes[1].mesh.positions[3 * idx2 + 0], monster_logo_shapes[1].mesh.positions[3 * idx2 + 1], monster_logo_shapes[1].mesh.positions[3 * idx2 + 2]);
		v3 = vec3(monster_logo_shapes[1].mesh.positions[3 * idx3 + 0], monster_logo_shapes[1].mesh.positions[3 * idx3 + 1], monster_logo_shapes[1].mesh.positions[3 * idx3 + 2]);

		// Normals calculations
		vec3 normal = cross(v2 - v1, v3 - v1);

		norBuf[3 * idx1 + 0] += normal.x;
		norBuf[3 * idx1 + 1] += normal.y;
		norBuf[3 * idx1 + 2] += normal.z;
		norBuf[3 * idx2 + 0] += normal.x;
		norBuf[3 * idx2 + 1] += normal.y;
		norBuf[3 * idx2 + 2] += normal.z;
		norBuf[3 * idx3 + 0] += normal.x;
		norBuf[3 * idx3 + 1] += normal.y;
		norBuf[3 * idx3 + 2] += normal.z;
	}

	glGenBuffers(1, &norBufObjL);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObjL);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);

	// Send the index array to the GPU
	const vector<unsigned int> &indBuf = monster_logo_shapes[1].mesh.indices;
	glGenBuffers(1, &indBufObjL);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjL);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);

	// Unbind the arrays
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	GLSL::checkVersion();
	//assert(glGetError() == GL_NO_ERROR);
}

void initGround()
{

	GLfloat g_backgnd_data[] = {
		-G_edge, FLOOR_DEPTH, -G_edge,
		-G_edge, FLOOR_DEPTH, G_edge,
		G_edge, FLOOR_DEPTH, -G_edge,
		-G_edge, FLOOR_DEPTH, G_edge,
		G_edge, FLOOR_DEPTH, -G_edge,
		G_edge, FLOOR_DEPTH, G_edge,
	};


	GLfloat nor_Buf_G[] = {
		0.4f, 0.0f, 0.3f,
		0.4f, 0.0f, 0.3f,
		0.4f, 0.0f, 0.3f,
		0.4f, 0.0f, 0.3f,
		0.4f, 0.0f, 0.3f,
		0.4f, 0.0f, 0.3f,
	};

	glGenBuffers(1, &posFloorBufObj);
	glBindBuffer(GL_ARRAY_BUFFER, posFloorBufObj);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_backgnd_data), g_backgnd_data, GL_STATIC_DRAW);

	glGenBuffers(1, &norFloorBufObj);
	glBindBuffer(GL_ARRAY_BUFFER, norFloorBufObj);
	glBufferData(GL_ARRAY_BUFFER, sizeof(nor_Buf_G), nor_Buf_G, GL_STATIC_DRAW);
}

void initGL()
{
	// Set the background color
	glClearColor(0.5f, 0.7f, 1.0f, 1.0f);
	// Enable Z-buffer test
	glEnable(GL_DEPTH_TEST);
	glPointSize(18);

	initBunny(bunny_shapes);
	initSkateboard(skateboard_shapes);
	initMonster(monster_can_shapes);
	initMonsterLogo(monster_logo_shapes);
	initGround();

	//initialize the modeltrans matrix stack
	ModelTrans.useModelViewMatrix();
	ModelTrans.loadIdentity();

}

/* model transforms */
mat4 SetModel(vec3 trans, float rot, float sc)
{
	mat4 Trans = translate(mat4(1.0f), trans);
	mat4 RotateY = rotate(mat4(1.0f), rot, vec3(0.0f, 1, 0));
	mat4 Sc = scale(mat4(1.0f), vec3(sc));
	return Trans*RotateY*Sc;
}

bool installShaders(const string &vShaderName, const string &fShaderName)
{
	GLint rc;

	// Create shader handles
	GLuint VS = glCreateShader(GL_VERTEX_SHADER);
	GLuint FS = glCreateShader(GL_FRAGMENT_SHADER);

	// Read shader sources
	const char *vshader = GLSL::textFileRead(vShaderName.c_str());
	const char *fshader = GLSL::textFileRead(fShaderName.c_str());
	glShaderSource(VS, 1, &vshader, NULL);
	glShaderSource(FS, 1, &fshader, NULL);

	// Compile vertex shader
	glCompileShader(VS);
	GLSL::printError();
	glGetShaderiv(VS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(VS);
	if (!rc)
	{
		printf("Error compiling vertex shader %s\n", vShaderName.c_str());
		return false;
	}

	// Compile fragment shader
	glCompileShader(FS);
	GLSL::printError();
	glGetShaderiv(FS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(FS);
	if (!rc)
	{
		printf("Error compiling fragment shader %s\n", fShaderName.c_str());
		return false;
	}

	// Create the program and link
	prog = glCreateProgram();
	glAttachShader(prog, VS);
	glAttachShader(prog, FS);
	glLinkProgram(prog);
	GLSL::printError();
	glGetProgramiv(prog, GL_LINK_STATUS, &rc);
	GLSL::printProgramInfoLog(prog);
	if (!rc)
	{
		printf("Error linking shaders %s and %s\n", vShaderName.c_str(), fShaderName.c_str());
		return false;
	}

	/* get handles to attribute data */
	h_aPosition = GLSL::getAttribLocation(prog, "aPosition");
	h_aNormal = GLSL::getAttribLocation(prog, "aNormal");
	h_uProjMatrix = GLSL::getUniformLocation(prog, "uProjMatrix");
	h_uViewMatrix = GLSL::getUniformLocation(prog, "uViewMatrix");
	h_uModelMatrix = GLSL::getUniformLocation(prog, "uModelMatrix");
	h_uLightPos = GLSL::getUniformLocation(prog, "uLightPos");
	h_uMatAmb = GLSL::getUniformLocation(prog, "UaColor");
	h_uMatDif = GLSL::getUniformLocation(prog, "UdColor");
	h_uMatSpec = GLSL::getUniformLocation(prog, "UsColor");
	h_uMatShine = GLSL::getUniformLocation(prog, "Ushine");

	assert(glGetError() == GL_NO_ERROR);
	return true;
}

void movement()
{
	// Camera controls
	GLfloat cameraSpeed = 0.2f;
	if (keys[GLFW_KEY_W])
		cameraPos += cameraSpeed * cameraFront;
	if (keys[GLFW_KEY_S])
		cameraPos -= cameraSpeed * cameraFront;
	if (keys[GLFW_KEY_A])
		cameraPos -= normalize(cross(cameraFront, cameraUp)) * cameraSpeed;
	if (keys[GLFW_KEY_D])
		cameraPos += normalize(cross(cameraFront, cameraUp)) * cameraSpeed;
}

randomizedInfo randomizeObjectModelMatrix(int rand1, int rand2, int rand3, float yAdjust)
{
	ModelTrans.loadIdentity();
	randomizedInfo returnInfo;
	returnInfo.material = rand() % 5;
	int xPos = (-1 * play_area) + (rand1 % (int)(play_area + 1));
	int zPos = (-1 * play_area) + (rand2 % (int)(play_area + 1));
	float rotation = rand3 % 360;
	returnInfo.modelMat = SetModel(vec3(xPos, FLOOR_DEPTH + yAdjust, zPos), rotation, 4);
	return returnInfo;
}

void drawGL(randomizedInfo skateboard[], randomizedInfo bunnies[], randomizedInfo can[], randomizedInfo logo[])
{
	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Use our GLSL program
	glUseProgram(prog);

	// Compute and send the projection matrix - leave this as is
	mat4 Projection = perspective(45.0f, (float)g_width / g_height, 0.1f, 100.f);
	glUniformMatrix4fv(h_uProjMatrix, 1, GL_FALSE, value_ptr(Projection));

	glUniform3f(h_uLightPos, 0.0f, 15.0f, 0.0f);
	view = lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

	//set up view matrix
	//view = lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
	glUniformMatrix4fv(h_uViewMatrix, 1, GL_FALSE, value_ptr(view));

	// DRAW ALL THE KEWL STUFF
	for (int i = 0; i < 10; i++)
	{
		// SKATEBOARDZ
		// Enable and bind position array for drawing
		GLSL::enableVertexAttribArray(h_aPosition);
		glBindBuffer(GL_ARRAY_BUFFER, posBufObjS);
		glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);

		// Enable and bind normal array for drawing
		GLSL::enableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, norBufObjS);
		glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
		// Bind index array for drawing
		int nIndices = (int)skateboard_shapes[0].mesh.indices.size();
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjS);
		SetMaterial(skateboard[i].material);
		glUniformMatrix4fv(h_uModelMatrix, 1, GL_FALSE, value_ptr(skateboard[i].modelMat));
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

		// Disable and unbind
		GLSL::disableVertexAttribArray(h_aPosition);
		GLSL::disableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

		// BUNNIES
		// Enable and bind position array for drawing
		GLSL::enableVertexAttribArray(h_aPosition);
		glBindBuffer(GL_ARRAY_BUFFER, posBufObjB);
		glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);

		// Enable and bind normal array for drawing
		GLSL::enableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, norBufObjB);
		glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
		// Bind index array for drawing
		nIndices = (int)bunny_shapes[0].mesh.indices.size();
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjB);
		SetMaterial(bunnies[i].material);
		glUniformMatrix4fv(h_uModelMatrix, 1, GL_FALSE, value_ptr(bunnies[i].modelMat));
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

		// Disable and unbind
		GLSL::disableVertexAttribArray(h_aPosition);
		GLSL::disableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

		// MONSTER
		// Enable and bind position array for drawing
		GLSL::enableVertexAttribArray(h_aPosition);
		glBindBuffer(GL_ARRAY_BUFFER, posBufObjM);
		glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);

		// Enable and bind normal array for drawing
		GLSL::enableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, norBufObjM);
		glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
		// Bind index array for drawing
		nIndices = (int)monster_can_shapes[0].mesh.indices.size();
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjM);
		SetMaterial(6);
		glUniformMatrix4fv(h_uModelMatrix, 1, GL_FALSE, value_ptr(can[i].modelMat));
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

		// Disable and unbind
		GLSL::disableVertexAttribArray(h_aPosition);
		GLSL::disableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

		// CAN
		// Enable and bind position array for drawing
		GLSL::enableVertexAttribArray(h_aPosition);
		glBindBuffer(GL_ARRAY_BUFFER, posBufObjL);
		glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);

		// Enable and bind normal array for drawing
		GLSL::enableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, norBufObjL);
		glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
		// Bind index array for drawing
		nIndices = (int)monster_logo_shapes[1].mesh.indices.size();
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObjL);
		SetMaterial(4);
		glUniformMatrix4fv(h_uModelMatrix, 1, GL_FALSE, value_ptr(logo[i].modelMat));
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

		// Disable and unbind
		GLSL::disableVertexAttribArray(h_aPosition);
		GLSL::disableVertexAttribArray(h_aNormal);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	}


	// DRAW FLOOR
	glUniformMatrix4fv(h_uModelMatrix, 1, GL_FALSE, value_ptr(SetModel(vec3(0), 0, 1)));
	glEnableVertexAttribArray(h_aPosition);
	glBindBuffer(GL_ARRAY_BUFFER, posFloorBufObj);
	glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	GLSL::enableVertexAttribArray(h_aNormal);
	glBindBuffer(GL_ARRAY_BUFFER, norFloorBufObj);
	glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);

	ModelTrans.loadIdentity();
	SetMaterial(7);
	glDrawArrays(GL_TRIANGLES, 0, 6);

	GLSL::disableVertexAttribArray(h_aPosition);
	GLSL::disableVertexAttribArray(h_aNormal);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glUseProgram(0);
	//assert(glGetError() == GL_NO_ERROR);
}

void reshapeGL(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	g_width = w;
	g_height = h;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (action == GLFW_PRESS)
		keys[key] = true;
	else if (action == GLFW_RELEASE)
		keys[key] = false;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	GLfloat xoffset = xpos - lastX;
	GLfloat yoffset = lastY - ypos;
	lastX = xpos;
	lastY = ypos;

	GLfloat sensitivity = 0.1;
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	theta += xoffset;
	phi += yoffset;

	if (phi > 80.0f)
		phi = 80.0f;
	if (phi < -80.0f)
		phi = -80.0f;

	vec3 front;
	front.x = cos(radians(theta)) * cos(radians(phi));
	front.y = sin(radians(phi));
	front.z = sin(radians(theta)) * cos(radians(phi));
	cameraFront = normalize(front);
}

int main(int argc, char **argv)
{
	srand(time(NULL));

	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);

	g_width = 1024;
	g_height = 768;
	// Open a window and create its OpenGL context
	window = glfwCreateWindow(g_width, g_height, "Bunny Sk8te Park - Connor Batch", NULL, NULL);
	if (window == NULL)
	{
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, key_callback);

	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

	// FOR MOUSE
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetCursorPos(window, 0.0, 0.0);


	loadShapes("spikybunny.obj", 1);
	loadShapes("skateboard.obj", 0);
	loadShapes("monster.obj", 2);
	loadShapes("monster.obj", 3);

	std::cout << " loaded the object " << endl;

	// Initialize GLEW
	if (glewInit() != GLEW_OK)
	{
		fprintf(stderr, "Failed to initialize GLEW\n");
		return -1;
	}

	initGL();
	installShaders("vert.glsl", "frag.glsl");

	randomizedInfo skateboards[10];
	randomizedInfo bunnies[10];

	for (int i = 0; i < 10; i++)
	{
		int rands[3];
		for (int j = 0; j < 3; j++)
		{
			rands[j] = rand();
		}
		skateboards[i] = randomizeObjectModelMatrix(rands[0], rands[1], rands[2], SKATEBOARD_ADJUST);
		bunnies[i] = randomizeObjectModelMatrix(rands[0], rands[1], rands[2], SKATEBOARD_ADJUST + BUNNY_ADJUST);
	}

	randomizedInfo logo[10];
	randomizedInfo can[10];

	for (int i = 0; i < 10; i++)
	{
		int rands[3];
		for (int j = 0; j < 3; j++)
		{
			rands[j] = rand();
		}
		logo[i] = randomizeObjectModelMatrix(rands[0], rands[1], rands[2], MONSTER_ADJUST);
		can[i] = randomizeObjectModelMatrix(rands[0], rands[1], rands[2], MONSTER_ADJUST);
	}

	mouse_callback(window, 0, 0);
	lastX = 0;
	lastY = 0;

	do
	{
		movement();
		drawGL(skateboards, bunnies, logo, can);
		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();

	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
	glfwWindowShouldClose(window) == 0);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}
