Project 4 - Bunny Sk8tePark - Connor Batch

This is a depiction of my most recent "myself as a bunny" drawing that was done in class, the setting is noon.

The cursor is disabled, so to exit the program, just hit escape. This is using mouse functionality, not the trackpad method; to look around, look left for left, right for right, up for up and down for down. Navigation is possible through the use of W and S to zoom and A and D for strafing.

Note the movement and panning should be very smooth, did some research, hope you enjoy it!